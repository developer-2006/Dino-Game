namespace Dino
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //heart
        int rnd_heart = 0;
        //random heart up or down
        int random_heart = 0;

        int start_space = 0;
        int record = 0;
        //speed cactus and heart and cloud
        int speed = 4;

        //record up save
        int record_save;

        //rnd night and day
        int rnd_weather = 1000;
        int bet_Weather = 1;

        //jump
        bool bet_jump_up = false;
        bool bet_jump_down = false;

        //stop
        bool bet_stop = false;

        //restart
        bool bet_restart = false;


        bool bet_location_heart = false;
        bool bet_heart_top = true;

        bool bet_spped_cacrus_heart = true;

        bool bet_jump_sound = true;

      //  bool bet_weather_left = true;
       // bool bet_weather_right = true;



        //keyboard
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                if (Dino.Top == 125 || Dino.Top == 133)
                {
                    bet_jump_up = true;
                    if (bet_jump_sound == true)
                    {
                        var player = new System.Media.SoundPlayer("Jump.wav");
                        player.Play();
                    }

                }

                //Restart
                if (bet_stop == true)
                {
                    start_space++;
                    if (start_space == 2)
                    {
                        var player = new System.Media.SoundPlayer("start_game.wav");
                        player.Play();
                        Restart();
                        bet_jump_sound = true;
                    }
                }
            }

        }

        //jump
        private void Jump_time_Tick(object sender, EventArgs e)
        {
            if (bet_stop == false)
            {
                if (bet_jump_up == true)
                {
                    //speed jump
                    Dino.Top -= 6;

                    if (Dino.Top < 30)
                    {
                        System.Threading.Thread.Sleep(20);
                        bet_jump_down = true;
                        bet_jump_up = false;
                    }
                }

                if (bet_jump_down == true)
                {
                    //speed Landing
                    Dino.Top += 6;

                    if (Dino.Top == 133)
                    {
                        bet_jump_down = false;
                    }
                }
            }
        }

        //stop
        void Stop()
        {
            rnd_heart++;

            if (rnd_heart == 3)
            {
                bet_jump_sound = false;
                var player = new System.Media.SoundPlayer("game_over.wav");
                player.Play();
                Heart.Image = Properties.Resources._0red_hearts;
                bet_stop = true;
                Dino.Image = Properties.Resources.Dead;
                Game_over.BringToFront();
                Game_over.Image = Properties.Resources.Game_Over;
            }
            if (rnd_heart == 1)
            {
                Heart.Image = Properties.Resources._2red_hearts;
            }
            if (rnd_heart == 2)
            {
                Heart.Image = Properties.Resources._1red_hearts;
            }
            bet_restart = true;
        }

        //restart
        void Restart()
        {
            Random rnd = new Random();
            int left_cactus1 = rnd.Next(0, 300);
            Cactus1.Left = 1000 + left_cactus1;

            Random rnda = new Random();
            int left_cactus2 = rnda.Next(310, 400);
            Cactus2.Left = 1000 + left_cactus2;

            start_space = 0;
            rnd_heart = 0;
            Dino.Image = Properties.Resources.running;
            Heart.Image = Properties.Resources._3red_hearts;
            Game_over.SendToBack();
            Game_over.Image = null;
            Cloud1.Left = 679;
            Cloud2.Left = 848;
            Cloud3.Left = 999;
            heart1.Left = 5000;
            label2.BringToFront();
            label3.BringToFront();
            if (record > record_save)
            {
                record_save = record;
            }
            record = 0;
            label2.Text = record_save + "";
            label1.Text = record + "";
            speed = 5;

            bet_Weather = 1;
            rnd_weather = 1000;
            Weather.Image = Properties.Resources.Sun1;
            BackColor = Color.DarkOrange;
            panel1.BackColor = Color.Peru;
            label1.ForeColor = Color.Black;
            label2.ForeColor = Color.White;
            label3.ForeColor = Color.White;
            bet_stop = false;
            bet_restart = false;
            bet_location_heart = true;
            bet_heart_top = true;
        }

        //get heart
        void get_heart()
        {
            if (rnd_heart == 1)
            {
                Heart.Image = Properties.Resources._3red_hearts;
                rnd_heart = 0;
                heart1.Image = null;
                Random rnd = new Random();
                int left_heart1 = rnd.Next(410, 500);
                heart1.Left = 5000 + left_heart1;
                if (heart1.Left == Cactus1.Left || heart1.Left == Cactus2.Left)
                {
                    heart1.Left += 40;
                }
                bet_restart = false;
                heart1.Image = Properties.Resources.heart;
            }
            if (rnd_heart == 2)
            {
                Heart.Image = Properties.Resources._2red_hearts;
                rnd_heart = 1;
                heart1.Image = null;
                Random rnd = new Random();
                int left_heart1 = rnd.Next(410, 500);
                heart1.Left = 5000 + left_heart1;
                if (heart1.Left == Cactus1.Left || heart1.Left == Cactus2.Left)
                {
                    heart1.Left += 40;
                }
                bet_restart = false;
                heart1.Image = Properties.Resources.heart;
            }
            bet_heart_top = true;
        }

        //collision1
        void Collision1()
        {

            int Dino_Top1;
            int Dino_Top2;
            int Cactus1_Left;

            //collision with cactus 1
            for (Cactus1_Left = 40; Cactus1_Left < 83; Cactus1_Left++)
            {
                for (Dino_Top1 = 133; Dino_Top1 > 110; Dino_Top1--)
                {
                    if (Dino.Top == Dino_Top1 && Cactus1.Left == Cactus1_Left)
                    {
                        if (bet_restart == false)
                        {
                            var player = new System.Media.SoundPlayer("Cactus_collision.wav");
                            player.Play();
                            Stop();
                        }


                    }

                }
                for (Dino_Top2 = 110; Dino_Top2 > 95; Dino_Top2--)
                {
                    if (Dino.Top == Dino_Top2 && Cactus1.Left == Cactus1_Left)
                    {
                        if (bet_restart == false)
                        {
                            var player = new System.Media.SoundPlayer("Cactus_collision.wav");
                            player.Play();
                            Stop();
                        }
                    }

                }

            }

            Dino_Top1 = 133;
            Dino_Top2 = 110;
            Cactus1_Left = 40;
        }

        //collision2
        void Collision2()
        {
            int Dino_Top3;
            int Cactus2_Left;

            //collision with cactus 2
            for (Cactus2_Left = 30; Cactus2_Left < 83; Cactus2_Left++)
            {
                for (Dino_Top3 = 133; Dino_Top3 > 110; Dino_Top3--)
                {
                    if (Dino.Top == Dino_Top3 && Cactus2.Left == Cactus2_Left)
                    {
                        if (bet_restart == false)
                        {
                            var player = new System.Media.SoundPlayer("Cactus_collision.wav");
                            player.Play();
                            Stop();
                        }
                    }

                }

            }

            Dino_Top3 = 133;
            Cactus2_Left = 30;
        }

        //collision3
        void Collision3()
        {
            if (random_heart == 1)
            {
                int Dino_Top4;
                int heart1_Left;

                //collision with heart 1
                for (heart1_Left = 20; heart1_Left < 83; heart1_Left++)
                {
                    for (Dino_Top4 = 100; Dino_Top4 > 80; Dino_Top4--)
                    {
                        if (Dino.Top == Dino_Top4 && heart1.Left == heart1_Left)
                        {
                            if (bet_restart == false)
                            {
                                var player = new System.Media.SoundPlayer("heart.wav");
                                player.Play();
                                get_heart();
                            }
                        }

                    }


                }

                Dino_Top4 = 104;
                heart1_Left = 20;
            }
            else
            {
                int Dino_Top5;
                int heart2_Left;

                //collision with heart 2
                for (heart2_Left = 30; heart2_Left < 83; heart2_Left++)
                {
                    for (Dino_Top5 = 133; Dino_Top5 > 110; Dino_Top5--)
                    {
                        if (Dino.Top == Dino_Top5 && heart1.Left == heart2_Left)
                        {
                            if (bet_restart == false)
                            {
                                var player = new System.Media.SoundPlayer("heart.wav");
                                player.Play();
                                get_heart();
                            }
                        }

                    }

                }

                Dino_Top5 = 133;
                heart2_Left = 30;
            }

        }

        //cactus speed
        private void cactus_speed_Tick(object sender, EventArgs e)
        {
            if (bet_stop == false)
            {

                record++;
                label1.Text = record + "";
                if (record == record_save)
                {
                    label1.ForeColor = Color.Red;
                }

                // night and day
                if (record == rnd_weather)
                {
                    if (bet_spped_cacrus_heart == true)
                    {

                        if (bet_Weather == 1)
                        {
                            speed += 1;
                            Weather.Image = Properties.Resources.Month;
                            BackColor = Color.Black;
                            panel1.BackColor = Color.DimGray;
                            label1.ForeColor = Color.White;
                            label2.ForeColor = Color.DimGray;
                            label3.ForeColor = Color.DimGray;
                            bet_Weather = 2;
                            rnd_weather += 1000;
                            var player1 = new System.Media.SoundPlayer("sound_night.wav");
                            player1.Play();
                        }
                        else
                        {
                            Weather.Image = Properties.Resources.Sun1;
                            BackColor = Color.DarkOrange;
                            panel1.BackColor = Color.Peru;
                            label1.ForeColor = Color.Black;
                            label2.ForeColor = Color.White;
                            label3.ForeColor = Color.White;
                            bet_Weather = 1;
                            rnd_weather += 1000;
                            var player1 = new System.Media.SoundPlayer("sound_day.wav");
                            player1.Play();
                        }
                        bet_spped_cacrus_heart = false;
                    }
                }

                //speed cactus1
                Cactus1.Left -= speed;


                if (Cactus1.Left < -50)
                {
                    if (bet_Weather == 1)
                    {
                        label1.ForeColor = Color.Black;
                    }
                    if (bet_Weather == 2)
                    {
                        label1.ForeColor = Color.White;
                    }

                    Random rnd = new Random();
                    int left_cactus1 = rnd.Next(0, 300);
                    Cactus1.Left = 1000 + left_cactus1;

                    for (int i = 0; i > 40; i++)
                    {
                        int cactus2_save = Cactus2.Left + i;
                        if (cactus2_save == Cactus1.Left)
                        {
                            Cactus1.Left += 40;
                        }
                    }

                    bet_restart = false;
                    bet_spped_cacrus_heart = true;

                }


                //speed cactus2
                Cactus2.Left -= speed;

                if (Cactus2.Left < -50)
                {
                    Random rnd = new Random();
                    int left_cactus2 = rnd.Next(310, 400);
                    Cactus2.Left = 1000 + left_cactus2;

                    for (int i = 0; i > 40; i++)
                    {
                        int cactus1_save = Cactus1.Left + i;
                        if (cactus1_save == Cactus2.Left)
                        {
                            Cactus2.Left += 40;
                        }
                    }

                    bet_restart = false;
                    bet_spped_cacrus_heart = true;
                }

                Collision1();
                Collision2();
            }
        }

        //mouse
        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            if (Dino.Top == 125 || Dino.Top == 133)
            {
                bet_jump_up = true;
                if (bet_jump_sound == true)
                {
                    var player = new System.Media.SoundPlayer("Jump.wav");
                    player.Play();
                }
            }

            // mous restart
            if (bet_stop == true)
            {
                start_space++;
                if (start_space == 2)
                {
                    var player = new System.Media.SoundPlayer("start_game.wav");
                    player.Play();
                    Restart();
                    bet_jump_sound = true;
                }
            }
        }

        //heart speed
        private void heart_speed_Tick(object sender, EventArgs e)
        {
            if (bet_stop == false)
            {
                if (rnd_heart != 0)
                {
                    if (bet_heart_top == true)
                    {
                        Random rnda = new Random();
                        random_heart = rnda.Next(0, 2);
                        if (random_heart == 1)
                        {
                            heart1.Top = 104;
                        }
                        else
                        {
                            heart1.Top = 150;
                        }
                        bet_heart_top = false;
                    }

                    if (bet_location_heart == false)
                    {
                        heart1.Left = 5000;
                        bet_location_heart = true;
                        heart1.Image = Properties.Resources.heart;
                    }

                    //speed heart
                    heart1.Left -= speed;

                    if (heart1.Left < 0)
                    {
                        Random rnd = new Random();
                        int left_heart1 = rnd.Next(410, 500);
                        heart1.Left = 5000 + left_heart1;

                        for (int i = 0; i > 10; i++)
                        {
                            int cactus1_save = Cactus1.Left + i;
                            int cactus2_save = Cactus2.Left + i;
                            if (cactus1_save == heart1.Left || cactus2_save == heart1.Left)
                            {
                                heart1.Left += 10;
                            }
                        }

                        if (heart1.Left == Cactus1.Left || heart1.Left == Cactus2.Left)
                        {
                            heart1.Left += 40;
                        }

                        bet_restart = false;
                    }

                    Collision3();
                }
            }
        }

        //cloud speed
        private void cloud_speed_Tick(object sender, EventArgs e)
        {
            if (bet_stop == false)
            {
                //speed Cloud
                Cloud1.Left -= speed;
                Cloud2.Left -= speed;
                Cloud3.Left -= speed;

               // int i = 700;                  
                
              //  if (record > i)
               // {
                   // if (bet_weather_left == true)
                   // {
                        //speed jump
                      //  Weather.Top -= 1;

                      //  if (Weather.Top < 0)
                       // {
                         //   bet_weather_left = false; 
                         //   if (record < 100)
                         //   {
                        //        bet_weather_right = true;
                         //   }
                      //  }
                  //  }

                  //  if (bet_weather_right == true)
                  //  {
                        //speed Landing
                     //   Weather.Top += 1;

                     //   if (Weather.Top == 273)
                      //  {
                         //   bet_weather_right = false;
                         //   bet_weather_left = true;
                  //  }
                  //  }
               // }


                if (Cloud1.Left < -80)
                {
                    Cloud1.Left = 679;
                }
                if (Cloud2.Left < -80)
                {
                    Cloud2.Left = 679;
                }
                if (Cloud3.Left < -80)
                {
                    Cloud3.Left = 679;
                }
            }
        }

    }
    }
    


