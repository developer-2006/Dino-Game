﻿namespace Dino
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.cloud_speed = new System.Windows.Forms.Timer(this.components);
            this.Dino = new System.Windows.Forms.PictureBox();
            this.Jump_time = new System.Windows.Forms.Timer(this.components);
            this.Cactus1 = new System.Windows.Forms.PictureBox();
            this.cactus_speed = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.Cactus2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Heart = new System.Windows.Forms.PictureBox();
            this.heart1 = new System.Windows.Forms.PictureBox();
            this.heart_speed = new System.Windows.Forms.Timer(this.components);
            this.Cloud1 = new System.Windows.Forms.PictureBox();
            this.Cloud2 = new System.Windows.Forms.PictureBox();
            this.Cloud3 = new System.Windows.Forms.PictureBox();
            this.Weather = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Game_over = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.Dino)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cactus1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cactus2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Heart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.heart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cloud1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cloud2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cloud3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Weather)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Game_over)).BeginInit();
            this.SuspendLayout();
            // 
            // cloud_speed
            // 
            this.cloud_speed.Enabled = true;
            this.cloud_speed.Interval = 1;
            this.cloud_speed.Tick += new System.EventHandler(this.cloud_speed_Tick);
            // 
            // Dino
            // 
            this.Dino.BackColor = System.Drawing.Color.Transparent;
            this.Dino.Image = global::Dino.Properties.Resources.running;
            this.Dino.Location = new System.Drawing.Point(58, 133);
            this.Dino.Name = "Dino";
            this.Dino.Size = new System.Drawing.Size(40, 43);
            this.Dino.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Dino.TabIndex = 0;
            this.Dino.TabStop = false;
            // 
            // Jump_time
            // 
            this.Jump_time.Enabled = true;
            this.Jump_time.Interval = 10;
            this.Jump_time.Tick += new System.EventHandler(this.Jump_time_Tick);
            // 
            // Cactus1
            // 
            this.Cactus1.AccessibleRole = System.Windows.Forms.AccessibleRole.TitleBar;
            this.Cactus1.BackColor = System.Drawing.Color.Transparent;
            this.Cactus1.Image = global::Dino.Properties.Resources.Photo_1651948651210__1_;
            this.Cactus1.Location = new System.Drawing.Point(1047, 131);
            this.Cactus1.Name = "Cactus1";
            this.Cactus1.Size = new System.Drawing.Size(23, 46);
            this.Cactus1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Cactus1.TabIndex = 1;
            this.Cactus1.TabStop = false;
            // 
            // cactus_speed
            // 
            this.cactus_speed.Enabled = true;
            this.cactus_speed.Interval = 10;
            this.cactus_speed.Tick += new System.EventHandler(this.cactus_speed_Tick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Peru;
            this.panel1.Location = new System.Drawing.Point(-1, 176);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(606, 45);
            this.panel1.TabIndex = 2;
            // 
            // Cactus2
            // 
            this.Cactus2.BackColor = System.Drawing.Color.Transparent;
            this.Cactus2.Image = global::Dino.Properties.Resources.Photo_1651948690556;
            this.Cactus2.Location = new System.Drawing.Point(1254, 143);
            this.Cactus2.Name = "Cactus2";
            this.Cactus2.Size = new System.Drawing.Size(32, 33);
            this.Cactus2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Cactus2.TabIndex = 3;
            this.Cactus2.TabStop = false;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(524, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 27);
            this.label1.TabIndex = 5;
            this.label1.Text = "0";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Heart
            // 
            this.Heart.BackColor = System.Drawing.Color.Transparent;
            this.Heart.Image = global::Dino.Properties.Resources._3red_hearts;
            this.Heart.Location = new System.Drawing.Point(8, 7);
            this.Heart.Name = "Heart";
            this.Heart.Size = new System.Drawing.Size(64, 21);
            this.Heart.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Heart.TabIndex = 6;
            this.Heart.TabStop = false;
            // 
            // heart1
            // 
            this.heart1.BackColor = System.Drawing.Color.Transparent;
            this.heart1.Location = new System.Drawing.Point(1131, 104);
            this.heart1.Name = "heart1";
            this.heart1.Size = new System.Drawing.Size(32, 25);
            this.heart1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.heart1.TabIndex = 7;
            this.heart1.TabStop = false;
            // 
            // heart_speed
            // 
            this.heart_speed.Enabled = true;
            this.heart_speed.Interval = 1;
            this.heart_speed.Tick += new System.EventHandler(this.heart_speed_Tick);
            // 
            // Cloud1
            // 
            this.Cloud1.BackColor = System.Drawing.Color.Transparent;
            this.Cloud1.Image = global::Dino.Properties.Resources.Cloud;
            this.Cloud1.Location = new System.Drawing.Point(679, 54);
            this.Cloud1.Name = "Cloud1";
            this.Cloud1.Size = new System.Drawing.Size(68, 37);
            this.Cloud1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Cloud1.TabIndex = 9;
            this.Cloud1.TabStop = false;
            // 
            // Cloud2
            // 
            this.Cloud2.BackColor = System.Drawing.Color.Transparent;
            this.Cloud2.Image = global::Dino.Properties.Resources.Cloud;
            this.Cloud2.Location = new System.Drawing.Point(848, 66);
            this.Cloud2.Name = "Cloud2";
            this.Cloud2.Size = new System.Drawing.Size(48, 28);
            this.Cloud2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Cloud2.TabIndex = 10;
            this.Cloud2.TabStop = false;
            // 
            // Cloud3
            // 
            this.Cloud3.BackColor = System.Drawing.Color.Transparent;
            this.Cloud3.Image = global::Dino.Properties.Resources.Cloud;
            this.Cloud3.Location = new System.Drawing.Point(999, 56);
            this.Cloud3.Name = "Cloud3";
            this.Cloud3.Size = new System.Drawing.Size(68, 37);
            this.Cloud3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Cloud3.TabIndex = 11;
            this.Cloud3.TabStop = false;
            // 
            // Weather
            // 
            this.Weather.Image = global::Dino.Properties.Resources.Sun1;
            this.Weather.Location = new System.Drawing.Point(273, 0);
            this.Weather.Name = "Weather";
            this.Weather.Size = new System.Drawing.Size(59, 54);
            this.Weather.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Weather.TabIndex = 12;
            this.Weather.TabStop = false;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(452, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 27);
            this.label2.TabIndex = 13;
            this.label2.Text = "0";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(406, 7);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 27);
            this.label3.TabIndex = 14;
            this.label3.Text = "HI";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(405, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 27);
            this.label4.TabIndex = 15;
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Game_over
            // 
            this.Game_over.BackColor = System.Drawing.Color.Transparent;
            this.Game_over.Location = new System.Drawing.Point(203, 63);
            this.Game_over.Name = "Game_over";
            this.Game_over.Size = new System.Drawing.Size(202, 74);
            this.Game_over.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Game_over.TabIndex = 4;
            this.Game_over.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.DarkOrange;
            this.ClientSize = new System.Drawing.Size(602, 219);
            this.Controls.Add(this.heart1);
            this.Controls.Add(this.Heart);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Dino);
            this.Controls.Add(this.Cactus1);
            this.Controls.Add(this.Cactus2);
            this.Controls.Add(this.Cloud1);
            this.Controls.Add(this.Cloud2);
            this.Controls.Add(this.Cloud3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Weather);
            this.Controls.Add(this.Game_over);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Dino";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseClick);
            ((System.ComponentModel.ISupportInitialize)(this.Dino)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cactus1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cactus2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Heart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.heart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cloud1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cloud2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cloud3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Weather)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Game_over)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox Dino;
        private System.Windows.Forms.Timer Jump_time;
        private PictureBox Cactus1;
        private System.Windows.Forms.Timer cactus_speed;
        private Panel panel1;
        private PictureBox Cactus2;
        private Label label1;
        private PictureBox Heart;
        private PictureBox heart1;
        private System.Windows.Forms.Timer heart_speed;
        private PictureBox Cloud1;
        private PictureBox Cloud2;
        private PictureBox Cloud3;
        private PictureBox Weather;
        private Label label2;
        private Label label3;
        private Label label4;
        private System.Windows.Forms.Timer cloud_speed;
        private PictureBox Game_over;
    }
}